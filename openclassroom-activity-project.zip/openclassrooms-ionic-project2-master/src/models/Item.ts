export class Item {
    isLent: boolean;

    constructor(public name: string){
        this.isLent = false;
    }
}